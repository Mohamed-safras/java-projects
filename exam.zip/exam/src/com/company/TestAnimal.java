package com.company;

public class TestAnimal {

    public static void main(String[] args) {
	Cat cat = new Cat(04,"fish") {
        @Override
        public void walk() {
            super.walk();
        }

        @Override
        public void talk() {
            super.talk();
        }
    };
	Duck duck = new Duck(02,"fish") {

        @Override
        public void walk() {
            super.walk();
        }

        @Override
        public void talk() {
            super.talk();
        }
    };
        cat.talk();
        cat.walk();
        duck.talk();
        duck.walk();

    }
}
